import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as eks from "aws-cdk-lib/aws-eks";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import { ConfigProps } from "./config";
import * as s3 from "aws-cdk-lib/aws-s3";
export interface helmStackProps extends cdk.StackProps {
    config: ConfigProps;
    vpc: ec2.Vpc;
    rdssecret: string;
    eksCluster: eks.FargateCluster;
    s3bucket: s3.Bucket;
    rdsHost: string;
}
export declare class helmStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props: helmStackProps);
}
