import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import { ConfigProps } from "./config";
import { StackProps } from "aws-cdk-lib";
type AwsEnvStackProps = StackProps & {
    config: Readonly<ConfigProps>;
};
export interface VpcStackProps extends cdk.StackProps {
    config: ConfigProps;
}
export declare class vpcStack extends cdk.Stack {
    readonly vpc: ec2.Vpc;
    constructor(scope: Construct, id: string, props: AwsEnvStackProps);
}
export {};
