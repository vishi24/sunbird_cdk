export type ConfigProps = {
    REGION: string;
    ACCOUNT: string;
    CIDR: string;
    RDS_SEC_GRP_INGRESS: string;
    MAX_AZS: number;
    BUCKET_NAME: string;
    CHART: string;
    REPOSITORY: string;
    NAMESPACE: string;
    RELEASE: string;
};
export declare const getConfig: () => ConfigProps;
