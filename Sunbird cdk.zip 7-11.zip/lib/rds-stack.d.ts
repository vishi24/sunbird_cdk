import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import { ConfigProps } from "./config";
export interface RdsStackProps extends cdk.StackProps {
    config: ConfigProps;
    vpc: ec2.Vpc;
}
export declare class rdsStack extends cdk.Stack {
    readonly rdsSecret: string;
    readonly rdsHost: string;
    constructor(scope: Construct, id: string, props: RdsStackProps);
}
