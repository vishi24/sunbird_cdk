import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as s3 from "aws-cdk-lib/aws-s3";
import { ConfigProps } from "./config";
import { StackProps } from "aws-cdk-lib";
type AwsEnvStackProps = StackProps & {
    config: Readonly<ConfigProps>;
};
export interface bucketStackProps extends cdk.StackProps {
    config: ConfigProps;
}
export declare class s3Stack extends cdk.Stack {
    readonly s3bucket: s3.Bucket;
    constructor(scope: Construct, id: string, props: AwsEnvStackProps);
}
export {};
