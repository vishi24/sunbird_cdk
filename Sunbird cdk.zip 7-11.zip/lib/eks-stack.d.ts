import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as eks from "aws-cdk-lib/aws-eks";
import { ConfigProps } from "./config";
export interface EksStackProps extends cdk.StackProps {
    config: ConfigProps;
    vpc: ec2.Vpc;
}
export declare class eksStack extends cdk.Stack {
    readonly eksCluster: eks.FargateCluster;
    constructor(scope: Construct, id: string, props: EksStackProps);
}
